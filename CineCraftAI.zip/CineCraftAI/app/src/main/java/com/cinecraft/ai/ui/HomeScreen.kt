package com.cinecraft.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cinecraft.ai.core.CapState
import com.cinecraft.ai.core.formatBytes
import com.cinecraft.ai.core.formatDuration

@Composable
fun HomeScreen(vm: MainViewModel, onNewAnalysis: () -> Unit, onOpenProject: (Long) -> Unit) {
    val status by vm.status.collectAsState()
    val projects by vm.projects.collectAsState()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("CineCraft AI", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(
            "Offline cinematic analysis studio. Phase 1: project foundation and video inspection.",
            color = CcMuted,
            fontSize = 13.sp
        )

        Button(onClick = onNewAnalysis, modifier = Modifier.fillMaxWidth()) { Text("New analysis") }

        Panel("Offline verification") {
            val s = status
            if (s == null) {
                Text("Checking...", color = CcMuted)
            } else if (!s.declaresInternetPermission) {
                Text("Network permission: NOT declared by this app", color = CcOk, fontWeight = FontWeight.SemiBold)
                Text(
                    "Read from the installed app's own manifest. Android will refuse network access " +
                        "for an app without it. This checks the permission only; it does not monitor traffic.",
                    color = CcMuted,
                    fontSize = 12.sp
                )
            } else {
                Text("WARNING: this build declares the INTERNET permission", color = CcWarn, fontWeight = FontWeight.SemiBold)
            }
        }

        Panel("Local capabilities") {
            val s = status
            if (s == null) {
                Text("Checking...", color = CcMuted)
            } else {
                s.capabilities.forEach { c ->
                    Column {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(c.name, fontSize = 14.sp, modifier = Modifier.weight(0.6f))
                            Text(
                                c.state.label,
                                fontSize = 11.sp,
                                color = if (c.state == CapState.BUILT) CcOk else CcMuted,
                                modifier = Modifier.weight(0.4f)
                            )
                        }
                        Text(c.detail, fontSize = 11.sp, color = CcMuted)
                    }
                }
            }
        }

        Panel("Storage") {
            val s = status
            if (s == null) {
                Text("Checking...", color = CcMuted)
            } else {
                Text("App data and cache: ${formatBytes(s.storage.appBytes)}")
                Text(
                    "Free on device: ${formatBytes(s.storage.freeBytes)} of ${formatBytes(s.storage.totalBytes)}",
                    color = CcMuted,
                    fontSize = 13.sp
                )
            }
        }

        Panel("Recent projects") {
            if (projects.isEmpty()) {
                Text("No projects yet. Start with New analysis.", color = CcMuted, fontSize = 13.sp)
            } else {
                projects.take(3).forEach { p ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(0.7f)) {
                            Text(p.title, fontSize = 14.sp)
                            Text(formatDuration(p.durationMs), fontSize = 11.sp, color = CcMuted)
                        }
                        androidx.compose.material3.TextButton(onClick = { onOpenProject(p.id) }) { Text("Continue") }
                    }
                }
            }
        }

        Panel("Help and limitations") {
            Text(
                "- Metadata is read from the file; fields a file does not report show as Unavailable.\n" +
                    "- Shot analysis, audio analysis, prompts and exports are not built yet.\n" +
                    "- No AI model is bundled. Nothing is described by AI unless a model is listed as installed.",
                fontSize = 12.sp,
                color = CcMuted
            )
        }
    }
}
