package com.cinecraft.ai.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cinecraft.ai.CineCraftApp
import com.cinecraft.ai.core.DeviceStatus
import com.cinecraft.ai.core.DeviceStatusReader
import com.cinecraft.ai.core.InspectResult
import com.cinecraft.ai.core.VideoInfo
import com.cinecraft.ai.core.VideoInspector
import com.cinecraft.ai.data.ProjectEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed interface InspectUi {
    data object Idle : InspectUi
    data object Working : InspectUi
    data class Ready(val info: VideoInfo, val savedProjectId: Long?) : InspectUi
    data class Error(val message: String) : InspectUi
}

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx = app.applicationContext
    private val dao = (app as CineCraftApp).db.projectDao()

    val projects: StateFlow<List<ProjectEntity>> =
        dao.observeAll().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _inspect = MutableStateFlow<InspectUi>(InspectUi.Idle)
    val inspect: StateFlow<InspectUi> = _inspect

    /** projectId -> whether the original video can still be opened. */
    private val _sourceOk = MutableStateFlow<Map<Long, Boolean>>(emptyMap())
    val sourceOk: StateFlow<Map<Long, Boolean>> = _sourceOk

    private val _status = MutableStateFlow<DeviceStatus?>(null)
    val status: StateFlow<DeviceStatus?> = _status

    init {
        refreshStatus()
        viewModelScope.launch {
            projects.collect { list ->
                _sourceOk.value = withContext(Dispatchers.IO) {
                    list.associate { it.id to VideoInspector.isReadable(ctx, Uri.parse(it.sourceUri)) }
                }
            }
        }
    }

    fun refreshStatus() {
        viewModelScope.launch {
            _status.value = withContext(Dispatchers.IO) { DeviceStatusReader.read(ctx) }
        }
    }

    fun inspect(uri: Uri) {
        _inspect.value = InspectUi.Working
        viewModelScope.launch {
            // Keep access to the chosen file across restarts without any storage permission.
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                // Some providers do not offer persistable grants; the project will then show a source warning later.
            }
            val result = withContext(Dispatchers.IO) { VideoInspector.inspect(ctx, uri) }
            _inspect.value = when (result) {
                is InspectResult.Ok -> InspectUi.Ready(result.info, null)
                is InspectResult.Failed -> InspectUi.Error(result.reason)
            }
        }
    }

    fun saveProject(info: VideoInfo, title: String) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val id = dao.insert(
                ProjectEntity(
                    title = title.ifBlank { info.displayName ?: "Untitled analysis" },
                    sourceUri = info.uri,
                    sourceName = info.displayName,
                    createdAt = now,
                    updatedAt = now,
                    durationMs = info.durationMs,
                    width = info.width,
                    height = info.height,
                    rotation = info.rotation,
                    frameRate = info.frameRate,
                    videoMime = info.videoMime,
                    audioMime = info.audioMime,
                    audioSampleRate = info.audioSampleRate,
                    audioChannels = info.audioChannels,
                    hasAudio = info.hasAudio,
                    sizeBytes = info.sizeBytes,
                    rangeStartMs = 0L,
                    rangeEndMs = info.durationMs
                )
            )
            File(ctx.filesDir, "projects/$id").mkdirs()
            _inspect.value = InspectUi.Ready(info, id)
            refreshStatus()
        }
    }

    fun openProject(p: ProjectEntity) {
        _inspect.value = InspectUi.Ready(
            VideoInfo(
                uri = p.sourceUri,
                displayName = p.sourceName,
                sizeBytes = p.sizeBytes,
                durationMs = p.durationMs,
                width = p.width,
                height = p.height,
                rotation = p.rotation,
                frameRate = p.frameRate,
                videoMime = p.videoMime,
                videoDecodable = null,
                audioMime = p.audioMime,
                audioSampleRate = p.audioSampleRate,
                audioChannels = p.audioChannels,
                hasAudio = p.hasAudio,
                warnings = emptyList()
            ),
            p.id
        )
    }

    fun renameProject(id: Long, title: String) {
        if (title.isBlank()) return
        viewModelScope.launch { dao.rename(id, title.trim(), System.currentTimeMillis()) }
    }

    fun deleteProject(id: Long) {
        viewModelScope.launch {
            dao.delete(id)
            withContext(Dispatchers.IO) { File(ctx.filesDir, "projects/$id").deleteRecursively() }
            val cur = _inspect.value
            if (cur is InspectUi.Ready && cur.savedProjectId == id) _inspect.value = InspectUi.Idle
            refreshStatus()
        }
    }
}
