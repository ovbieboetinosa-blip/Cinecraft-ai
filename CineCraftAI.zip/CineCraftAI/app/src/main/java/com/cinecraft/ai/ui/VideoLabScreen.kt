package com.cinecraft.ai.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cinecraft.ai.core.VideoInfo
import com.cinecraft.ai.core.formatBytes
import com.cinecraft.ai.core.formatDuration

@Composable
fun VideoLabScreen(vm: MainViewModel) {
    val state by vm.inspect.collectAsState()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.inspect(uri)
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Video Lab", fontSize = 22.sp, fontWeight = FontWeight.Bold)

        Button(onClick = { picker.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth()) {
            Text("Choose a video")
        }

        when (val s = state) {
            InspectUi.Idle -> Panel("No video selected") {
                Text(
                    "Pick a video with the system file picker. The app needs no storage permission and " +
                        "never copies the video.",
                    color = CcMuted,
                    fontSize = 13.sp
                )
            }

            InspectUi.Working -> Panel("Reading file") {
                CircularProgressIndicator()
                Text("Inspecting metadata...", color = CcMuted, fontSize = 13.sp)
            }

            is InspectUi.Error -> Panel("Cannot use this file") {
                Text(s.message, color = CcWarn, fontSize = 14.sp)
            }

            is InspectUi.Ready -> InfoPanels(s.info, s.savedProjectId, vm)
        }

        NotBuiltYet(
            "Analysis tools",
            "Phase 2",
            listOf(
                "Video preview and analysis-range selection",
                "Frame extraction, contact sheets",
                "Scene-change detection and frame measurements",
                "Shot timeline with manual descriptions"
            )
        )
    }
}

@Composable
private fun InfoPanels(info: VideoInfo, savedId: Long?, vm: MainViewModel) {
    Panel("Source file") {
        InfoRow("Name", info.displayName)
        InfoRow("File size", info.sizeBytes?.let { formatBytes(it) })
        InfoRow("Duration", info.durationMs?.let { formatDuration(it) })
    }
    Panel("Video") {
        InfoRow("Codec (MIME)", info.videoMime)
        InfoRow("Coded resolution", if (info.width != null && info.height != null) "${info.width} x ${info.height}" else null)
        InfoRow("Rotation flag", info.rotation?.let { "$it degrees" })
        InfoRow(
            "Displayed as",
            if (info.displayWidth != null && info.displayHeight != null) "${info.displayWidth} x ${info.displayHeight}" else null
        )
        InfoRow("Frame rate", info.frameRate?.let { "$it fps (as reported by the container)" })
        InfoRow(
            "Decoder on this phone",
            when (info.videoDecodable) {
                true -> "Available"
                false -> "NOT available"
                null -> null
            }
        )
    }
    Panel("Audio") {
        InfoRow("Audio track", if (info.hasAudio) "Present" else "None")
        InfoRow("Codec (MIME)", info.audioMime)
        InfoRow("Sample rate", info.audioSampleRate?.let { "$it Hz" })
        InfoRow("Channels", info.audioChannels?.toString())
    }
    Panel("Analysis range") {
        InfoRow("Start", formatDuration(0L))
        InfoRow("End", info.durationMs?.let { formatDuration(it) })
        Text("Range selection arrives in Phase 2. For now the full file is the range.", color = CcMuted, fontSize = 12.sp)
    }
    if (info.warnings.isNotEmpty()) {
        Panel("Notes") {
            info.warnings.forEach { Text("- $it", color = CcWarn, fontSize = 13.sp) }
        }
    }

    if (savedId == null) {
        var title by remember(info.uri) { mutableStateOf(info.displayName?.substringBeforeLast('.') ?: "") }
        Panel("Save as project") {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Project title") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = { vm.saveProject(info, title) }, modifier = Modifier.fillMaxWidth()) {
                Text("Create project")
            }
            Text(
                "Stores the metadata above and a reference to the video on this phone only.",
                color = CcMuted,
                fontSize = 12.sp
            )
        }
    } else {
        Panel("Project") {
            Text("Saved as project #$savedId on this phone.", color = CcOk, fontSize = 14.sp)
            Text("Rename or delete it from the Projects tab.", color = CcMuted, fontSize = 12.sp)
        }
    }
}
