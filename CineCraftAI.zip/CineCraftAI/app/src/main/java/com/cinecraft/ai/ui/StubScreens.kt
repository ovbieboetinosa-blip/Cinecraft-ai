package com.cinecraft.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AudioLabScreen() {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Audio Lab", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        NotBuiltYet(
            "Audio analysis",
            "Phase 3",
            listOf(
                "Waveform from decoded samples, RMS and peak, silence regions",
                "Candidate events from amplitude changes (no sound labelling without a model)",
                "Manual transcript editor and audio observations"
            )
        )
    }
}

@Composable
fun PromptWorkshopScreen() {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Prompt Workshop", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        NotBuiltYet(
            "Prompt generation",
            "Phase 4",
            listOf(
                "Editable 22-field shot prompts, template-assembled (not AI-generated)",
                "Style presets and master style lock",
                "Shot variations, prompt history, copy controls"
            )
        )
    }
}
