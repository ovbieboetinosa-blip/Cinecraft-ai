package com.cinecraft.ai.core

import java.util.Locale

fun formatDuration(ms: Long?): String {
    if (ms == null || ms < 0) return "Unavailable"
    val totalSeconds = ms / 1000
    val h = totalSeconds / 3600
    val m = (totalSeconds % 3600) / 60
    val s = totalSeconds % 60
    val milli = ms % 1000
    return if (h > 0) {
        String.format(Locale.US, "%d:%02d:%02d.%03d", h, m, s, milli)
    } else {
        String.format(Locale.US, "%d:%02d.%03d", m, s, milli)
    }
}

fun formatBytes(bytes: Long?): String {
    if (bytes == null || bytes < 0) return "Unavailable"
    val kb = 1024.0
    val mb = kb * 1024
    val gb = mb * 1024
    return when {
        bytes >= gb -> String.format(Locale.US, "%.2f GB", bytes / gb)
        bytes >= mb -> String.format(Locale.US, "%.1f MB", bytes / mb)
        bytes >= kb -> String.format(Locale.US, "%.0f KB", bytes / kb)
        else -> "$bytes B"
    }
}
