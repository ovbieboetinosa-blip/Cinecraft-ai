package com.cinecraft.ai.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One analysis project. Only a *reference* (persisted document URI) to the source video is
 * stored - the video itself is never copied. Larger derived assets (frames, contact sheets,
 * reports) will live in filesDir/projects/<id>/ in later phases.
 */
@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val sourceUri: String,
    val sourceName: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val durationMs: Long?,
    val width: Int?,
    val height: Int?,
    val rotation: Int?,
    val frameRate: Float?,
    val videoMime: String?,
    val audioMime: String?,
    val audioSampleRate: Int?,
    val audioChannels: Int?,
    val hasAudio: Boolean,
    val sizeBytes: Long?,
    val rangeStartMs: Long,
    val rangeEndMs: Long?
)
