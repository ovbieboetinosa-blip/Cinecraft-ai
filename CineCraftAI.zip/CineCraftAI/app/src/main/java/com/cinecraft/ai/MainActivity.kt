package com.cinecraft.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.cinecraft.ai.ui.AppRoot
import com.cinecraft.ai.ui.CineCraftTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CineCraftTheme {
                AppRoot()
            }
        }
    }
}
