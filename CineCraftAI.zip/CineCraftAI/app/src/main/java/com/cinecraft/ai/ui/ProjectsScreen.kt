package com.cinecraft.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cinecraft.ai.core.formatBytes
import com.cinecraft.ai.core.formatDuration
import com.cinecraft.ai.data.ProjectEntity

@Composable
fun ProjectsScreen(vm: MainViewModel, onOpen: (ProjectEntity) -> Unit) {
    val projects by vm.projects.collectAsState()
    val sourceOk by vm.sourceOk.collectAsState()
    var renaming by remember { mutableStateOf<ProjectEntity?>(null) }
    var deleting by remember { mutableStateOf<ProjectEntity?>(null) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Projects & Exports", fontSize = 22.sp, fontWeight = FontWeight.Bold)

        if (projects.isEmpty()) {
            Panel("No projects") {
                Text("Create one from the Video Lab after choosing a video.", color = CcMuted, fontSize = 13.sp)
            }
        }

        projects.forEach { p ->
            Panel(p.title) {
                Text(
                    "${p.sourceName ?: "Unknown file"} - ${formatDuration(p.durationMs)} - ${formatBytes(p.sizeBytes)}",
                    color = CcMuted,
                    fontSize = 12.sp
                )
                if (sourceOk[p.id] == false) {
                    Text(
                        "Source video cannot be opened. It may have been moved or deleted, or access was lost. " +
                            "Saved metadata is still here.",
                        color = CcWarn,
                        fontSize = 12.sp
                    )
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = { onOpen(p) }) { Text("Open") }
                    TextButton(onClick = { renaming = p }) { Text("Rename") }
                    TextButton(onClick = { deleting = p }) { Text("Delete") }
                }
            }
        }

        NotBuiltYet(
            "Exports and backups",
            "Phase 5",
            listOf(
                "TXT, Markdown, PDF, CSV exports",
                "JSON backup and restore",
                "Duplicate project, clear cached frames"
            )
        )
    }

    renaming?.let { p ->
        var text by remember(p.id) { mutableStateOf(p.title) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("Rename project") },
            text = {
                OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true)
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.renameProject(p.id, text)
                    renaming = null
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Cancel") } }
        )
    }

    deleting?.let { p ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete \"${p.title}\"?") },
            text = {
                Text(
                    "This removes the project record and any files this app created for it. " +
                        "Your original video is not touched. This cannot be undone."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteProject(p.id)
                    deleting = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } }
        )
    }
}
