package com.cinecraft.ai.core

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.StatFs
import java.io.File

data class StorageStats(val appBytes: Long, val freeBytes: Long, val totalBytes: Long)

enum class CapState(val label: String) {
    BUILT("Built in this version"),
    PLANNED("Planned - not in this build"),
    NOT_INSTALLED("Not installed")
}

data class Capability(val name: String, val state: CapState, val detail: String)

data class DeviceStatus(
    /** Read from the installed app's merged manifest, so it reflects what Android really granted. */
    val declaresInternetPermission: Boolean,
    val storage: StorageStats,
    val capabilities: List<Capability>
)

object DeviceStatusReader {

    fun read(context: Context): DeviceStatus {
        return DeviceStatus(
            declaresInternetPermission = declaresInternet(context),
            storage = storage(context),
            capabilities = capabilities()
        )
    }

    private fun declaresInternet(context: Context): Boolean {
        val info = context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_PERMISSIONS)
        return info.requestedPermissions?.contains(Manifest.permission.INTERNET) == true
    }

    private fun storage(context: Context): StorageStats {
        val used = dirSize(context.filesDir) + dirSize(context.cacheDir)
        val stat = StatFs(context.filesDir.path)
        return StorageStats(used, stat.availableBytes, stat.totalBytes)
    }

    private fun dirSize(f: File): Long {
        if (!f.exists()) return 0L
        if (f.isFile) return f.length()
        var total = 0L
        f.listFiles()?.forEach { total += dirSize(it) }
        return total
    }

    /** Honest static capability list. Models are never READY in Phase 1: no runtime is integrated. */
    private fun capabilities(): List<Capability> = listOf(
        Capability("Video import & metadata", CapState.BUILT, "System file picker + MediaMetadataRetriever/MediaExtractor"),
        Capability("Project database", CapState.BUILT, "Local Room/SQLite storage"),
        Capability("Frame extraction, contact sheets, scene detection", CapState.PLANNED, "Phase 2"),
        Capability("Audio waveform & signal analysis", CapState.PLANNED, "Phase 3"),
        Capability("Prompt Workshop & style lock", CapState.PLANNED, "Phase 4"),
        Capability("Exports (TXT, MD, PDF, CSV, JSON)", CapState.PLANNED, "Phase 5"),
        Capability("Speech recognition model", CapState.NOT_INSTALLED, "No model bundled; no runtime integrated"),
        Capability("Image captioning model", CapState.NOT_INSTALLED, "No model bundled; no runtime integrated")
    )
}
