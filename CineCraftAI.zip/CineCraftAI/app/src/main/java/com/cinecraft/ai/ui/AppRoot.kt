package com.cinecraft.ai.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController

enum class Dest(val route: String, val label: String, val glyph: String) {
    Home("home", "Studio", "⌂"),
    Video("video", "Video", "▶"),
    Audio("audio", "Audio", "♪"),
    Prompts("prompts", "Prompts", "✎"),
    Projects("projects", "Projects", "▤")
}

private fun NavHostController.goTo(d: Dest) {
    navigate(d.route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun AppRoot(vm: MainViewModel = viewModel()) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val current = backStack?.destination?.route

    Scaffold(
        containerColor = CcBackground,
        bottomBar = {
            NavigationBar(containerColor = CcSurface) {
                Dest.values().forEach { d ->
                    NavigationBarItem(
                        selected = current == d.route,
                        onClick = { nav.goTo(d) },
                        icon = { Text(d.glyph) },
                        label = { Text(d.label) }
                    )
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = Dest.Home.route, modifier = Modifier.padding(pad)) {
            composable(Dest.Home.route) {
                HomeScreen(
                    vm = vm,
                    onNewAnalysis = { nav.goTo(Dest.Video) },
                    onOpenProject = { id ->
                        vm.projects.value.firstOrNull { it.id == id }?.let { vm.openProject(it) }
                        nav.goTo(Dest.Video)
                    }
                )
            }
            composable(Dest.Video.route) { VideoLabScreen(vm) }
            composable(Dest.Audio.route) { AudioLabScreen() }
            composable(Dest.Prompts.route) { PromptWorkshopScreen() }
            composable(Dest.Projects.route) {
                ProjectsScreen(vm, onOpen = { p ->
                    vm.openProject(p)
                    nav.goTo(Dest.Video)
                })
            }
        }
    }
}
