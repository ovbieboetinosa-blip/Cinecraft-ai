package com.cinecraft.ai.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val CcBackground = Color(0xFF0E0F12)
val CcSurface = Color(0xFF16181D)
val CcSurfaceHigh = Color(0xFF1F2229)
val CcAccent = Color(0xFFE0A84E)
val CcText = Color(0xFFE8E6E1)
val CcMuted = Color(0xFF9A9CA3)
val CcOk = Color(0xFF6FBF8E)
val CcWarn = Color(0xFFE5826B)

private val scheme = darkColorScheme(
    primary = CcAccent,
    onPrimary = Color(0xFF1A1305),
    background = CcBackground,
    onBackground = CcText,
    surface = CcSurface,
    onSurface = CcText,
    surfaceVariant = CcSurfaceHigh,
    onSurfaceVariant = CcMuted,
    secondaryContainer = CcSurfaceHigh,
    onSecondaryContainer = CcAccent,
    error = CcWarn
)

@Composable
fun CineCraftTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
