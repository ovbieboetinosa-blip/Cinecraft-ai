package com.cinecraft.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cinecraft.ai.core.Origin

@Composable
fun Panel(title: String, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = CcAccent)
            content()
        }
    }
}

/** A labelled value with its provenance. A null value is always shown as Unavailable. */
@Composable
fun InfoRow(label: String, value: String?, origin: Origin = Origin.MEASURED) {
    val shown = value ?: "Unavailable"
    val tag = if (value == null) Origin.UNAVAILABLE else origin
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = CcMuted, fontSize = 13.sp, modifier = Modifier.weight(0.42f))
        Column(Modifier.weight(0.58f)) {
            Text(shown, fontSize = 14.sp)
            Text(tag.label, color = CcMuted, fontSize = 10.sp)
        }
    }
}

@Composable
fun NotBuiltYet(title: String, phase: String, planned: List<String>) {
    Panel(title) {
        Text("Not built yet - scheduled for $phase.", color = CcWarn, fontSize = 14.sp)
        Text(
            "Nothing on this screen is simulated. When this section exists it will only show real " +
                "measurements or content you entered.",
            color = CcMuted,
            fontSize = 13.sp
        )
        Text("Planned:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        planned.forEach { Text("- $it", fontSize = 13.sp, color = CcMuted) }
    }
}
