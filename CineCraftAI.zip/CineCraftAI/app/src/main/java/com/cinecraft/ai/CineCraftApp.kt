package com.cinecraft.ai

import android.app.Application
import androidx.room.Room
import com.cinecraft.ai.data.AppDatabase

class CineCraftApp : Application() {
    val db: AppDatabase by lazy {
        Room.databaseBuilder(this, AppDatabase::class.java, "cinecraft.db").build()
    }
}
