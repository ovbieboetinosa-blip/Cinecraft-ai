package com.cinecraft.ai.core

import android.content.Context
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns

/** Technical metadata read from the file. Every field here has Origin.MEASURED (or is null = unavailable). */
data class VideoInfo(
    val uri: String,
    val displayName: String?,
    val sizeBytes: Long?,
    val durationMs: Long?,
    val width: Int?,
    val height: Int?,
    val rotation: Int?,
    val frameRate: Float?,
    val videoMime: String?,
    val videoDecodable: Boolean?,
    val audioMime: String?,
    val audioSampleRate: Int?,
    val audioChannels: Int?,
    val hasAudio: Boolean,
    val warnings: List<String>
) {
    /** Dimensions as displayed to the viewer (coded size swapped for 90/270 degree rotation). */
    val displayWidth: Int? get() = if (rotation == 90 || rotation == 270) height else width
    val displayHeight: Int? get() = if (rotation == 90 || rotation == 270) width else height
}

sealed interface InspectResult {
    data class Ok(val info: VideoInfo) : InspectResult
    data class Failed(val reason: String) : InspectResult
}

object VideoInspector {

    /** Blocking. Call from a background dispatcher. */
    fun inspect(context: Context, uri: Uri): InspectResult {
        val warnings = mutableListOf<String>()
        val (name, size) = queryNameAndSize(context, uri)

        val retriever = MediaMetadataRetriever()
        var duration: Long? = null
        var width: Int? = null
        var height: Int? = null
        var rotation: Int? = null
        var hasVideoFlag = false
        var hasAudioFlag = false
        try {
            try {
                retriever.setDataSource(context, uri)
            } catch (e: Exception) {
                return InspectResult.Failed(
                    "This file could not be opened as media. It may be corrupt, or its format " +
                        "is not supported by this phone (${e.javaClass.simpleName})."
                )
            }
            duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull()
            height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()
            rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull()
            hasVideoFlag = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO) == "yes"
            hasAudioFlag = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO) == "yes"
        } finally {
            retriever.release()
        }

        // Track-level details via MediaExtractor.
        var videoMime: String? = null
        var frameRate: Float? = null
        var audioMime: String? = null
        var sampleRate: Int? = null
        var channels: Int? = null
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, uri, null)
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") && videoMime == null) {
                    videoMime = mime
                    frameRate = readFrameRate(f)
                    if (width == null && f.containsKey(MediaFormat.KEY_WIDTH)) width = f.getInteger(MediaFormat.KEY_WIDTH)
                    if (height == null && f.containsKey(MediaFormat.KEY_HEIGHT)) height = f.getInteger(MediaFormat.KEY_HEIGHT)
                } else if (mime.startsWith("audio/") && audioMime == null) {
                    audioMime = mime
                    if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sampleRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            }
        } catch (e: Exception) {
            warnings += "Track details could not be read (${e.javaClass.simpleName}); codec, frame rate and audio format may be missing."
        } finally {
            extractor.release()
        }

        if (!hasVideoFlag && videoMime == null) {
            return InspectResult.Failed("No video track was found in this file.")
        }

        val decodable = videoMime?.let { hasDecoder(it) }
        if (decodable == false) {
            warnings += "This phone has no decoder for $videoMime. Frames cannot be extracted from this file."
        }
        val hasAudio = hasAudioFlag || audioMime != null
        if (!hasAudio) warnings += "No audio track: the Audio Lab will have nothing to analyse for this file."
        if (frameRate == null) warnings += "Frame rate is not reported by this file."

        return InspectResult.Ok(
            VideoInfo(
                uri = uri.toString(),
                displayName = name,
                sizeBytes = size,
                durationMs = duration,
                width = width,
                height = height,
                rotation = rotation,
                frameRate = frameRate,
                videoMime = videoMime,
                videoDecodable = decodable,
                audioMime = audioMime,
                audioSampleRate = sampleRate,
                audioChannels = channels,
                hasAudio = hasAudio,
                warnings = warnings
            )
        )
    }

    private fun readFrameRate(f: MediaFormat): Float? {
        if (!f.containsKey(MediaFormat.KEY_FRAME_RATE)) return null
        return try {
            f.getInteger(MediaFormat.KEY_FRAME_RATE).toFloat()
        } catch (e: Exception) {
            try { f.getFloat(MediaFormat.KEY_FRAME_RATE) } catch (e2: Exception) { null }
        }
    }

    private fun hasDecoder(mime: String): Boolean {
        return try {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { info ->
                !info.isEncoder && info.supportedTypes.any { it.equals(mime, ignoreCase = true) }
            }
        } catch (e: Exception) {
            true // cannot tell; do not raise a false alarm
        }
    }

    private fun queryNameAndSize(context: Context, uri: Uri): Pair<String?, Long?> {
        var name: String? = null
        var size: Long? = null
        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni)
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
        } catch (e: Exception) {
            // name/size stay null = unavailable
        }
        return name to size
    }

    /** True if the stored reference can still be opened (file not moved/deleted, permission kept). */
    fun isReadable(context: Context, uri: Uri): Boolean {
        return try {
            context.contentResolver.openFileDescriptor(uri, "r")?.use { true } ?: false
        } catch (e: Exception) {
            false
        }
    }
}
