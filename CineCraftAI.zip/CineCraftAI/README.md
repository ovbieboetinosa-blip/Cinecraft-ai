# CineCraft AI (Phase 1)

Offline-first Android app for breaking videos into shot-by-shot production blueprints. Target: OPPO F11, Android 9 (API 28).

**Current state: Phase 1 source only. Not yet compiled, not yet run on any device.** See the matrix below.

## Build the APK without a computer (GitHub Actions)
1. Create a free GitHub repository (private is fine) from your phone's browser.
2. Upload the contents of this folder keeping the structure (including the hidden `.github/workflows/build-apk.yml`). Easiest is the zip: upload it via the GitHub web "Upload files" on desktop mode, or push from Termux.
3. Open the repo's **Actions** tab, choose **Build CineCraft AI APK**, press **Run workflow**.
4. When it finishes, open the run and download the artifact **CineCraftAI-debug-apk**, unzip it, and install `app-debug.apk` (allow "install from this source" when Android asks).
5. The workflow also fails the build if the APK requests the INTERNET permission.

If the build fails, copy the red error lines from the Actions log and send them to me; first-time compile errors are likely because this code has not been compiled yet.

## Build with Android Studio (if you get a computer)
Open this folder in Android Studio (JDK 17), let it sync, then Run on a phone with USB debugging, or Build > Build APK.

## Feature matrix
| Feature | Status |
|---|---|
| Gradle project, theme, 5-tab navigation | Written, not compiled |
| Room project database (create, rename, delete) | Written, not compiled |
| Video picker via system document picker (no permissions) | Written, not compiled |
| Metadata: duration, size, resolution, rotation, codec, frame rate, audio track, decoder check | Written, not compiled |
| Offline check (reads app's own permission list), storage usage, capability list | Written, not compiled |
| Source-missing warning on projects | Written, not compiled |
| Range selection, preview, frames, contact sheets, scene detection, measurements | Not built (Phase 2) |
| Audio Lab | Not built (Phase 3) |
| Prompt Workshop, style lock | Not built (Phase 4) |
| Exports, backup/restore | Not built (Phase 5) |
| Local speech / vision models | Not built; none installed (Phase 6) |
| Physical-device testing | Not done |

## Offline verification checklist
- [ ] Manifest has no `uses-permission` entries (true in source: `app/src/main/AndroidManifest.xml`).
- [ ] CI step "Verify the APK declares no INTERNET permission" passes.
- [ ] Studio tab shows "Network permission: NOT declared".
- [ ] Turn on airplane mode, open the app, pick a video, create a project.

## Licences
This project's code: yours to use. Dependencies are AndroidX, Jetpack Compose, Room, Navigation, Kotlin coroutines (all Apache-2.0). No models or native libraries are bundled yet.

## Known limitations
- Frame rate comes from container metadata and is often missing; shown as Unavailable then.
- Persisted access to the picked file depends on the file provider; if it fails the project shows a source warning.
- Placeholder launcher icon.
