# CineCraft AI - Feasibility Assessment for OPPO F11 / Android 9

Status labels used below: **Verified** (checked in this session), **From spec sheet** (published specs, not measured on your phone), **Estimate**, **Unverified candidate**.

## Target device (From spec sheet, 91mobiles)
MediaTek Helio P70 (4x Cortex-A73 2.1 GHz + 4x Cortex-A53 2.0 GHz, 12 nm), Mali-G72 MP3, 4 GB or 6 GB RAM, 128 GB storage, 1080x2340 display, Android 9 with ColorOS. Check your RAM variant in Settings > About phone. None of this has been measured on your actual unit.

## 1. Architecture
Single Android module, Kotlin, Jetpack Compose UI, one ViewModel, Room database. Layers:
- `core/` - media inspection and (later) analysis engines. Plain Kotlin, no UI, no Android UI types.
- `data/` - Room entities/DAO. Structured metadata only; large assets go to `filesDir/projects/<id>/`.
- `ui/` - Compose screens. Five tabs: Studio, Video, Audio, Prompts, Projects.
- `core/Origin.kt` - provenance enum (Measured / Local model / Entered by you / Unavailable) and `LocalModelAdapter`, the seam where optional models plug in later without touching engines, DB or UI.

## 2. SDK and dependency strategy
minSdk 28 (Android 9), compileSdk/targetSdk 34. Pinned compatible set: AGP 8.5.2, Gradle 8.7, Kotlin 1.9.24, KSP 1.9.24-1.0.20, Compose compiler 1.5.14, Compose BOM 2024.06.00, Room 2.6.1, Navigation 2.7.7, Lifecycle 2.8.3. All support API 21+ per AndroidX release policy, so API 28 is fine. These versions are deliberately conservative; newer ones were not needed.

## 3. Multimedia libraries
Android platform APIs only, no FFmpeg:
- `MediaMetadataRetriever` - duration, size, rotation, and `getFrameAtTime` for frame extraction (Phase 2).
- `MediaExtractor` - track formats (codec, sample rate, channels).
- `MediaCodec` - audio decoding to PCM for waveform (Phase 3). Video decoding only if `getFrameAtTime` proves too slow or imprecise.
- `MediaCodecList` - tells us whether the phone has a decoder for a file's codec.
- `android.graphics.pdf.PdfDocument` - local PDF export (Phase 5).
Reason: zero added APK size, no native-library/licence risk, and the phone's hardware decoders are used. FFmpeg would add roughly 10-30 MB per ABI (Estimate) and licence obligations; only worth it if platform APIs fail on real files.

## 4. Storage
Room/SQLite for project metadata and (later) shots, annotations, prompts. Files in app-private `filesDir/projects/<id>/` for frames, contact sheets, waveforms. Source videos are never copied; only a persisted document URI is stored, and the app shows a warning if it can no longer be opened. Exports go through the system "create document" picker.

## 5. Memory management
Frames are decoded at reduced size and written straight to disk, one at a time (small batches), and bitmaps are recycled after use. Audio is decoded in streaming chunks and reduced to per-window RMS/peak values, never held whole. Long jobs run on coroutines with cancellation checks. Three profiles (Low Memory / Balanced / Detailed) will set frame size and sampling density. Speeds will be benchmarked on your phone, not claimed.

## 6. Works without any AI model
Import and metadata, range selection, frame extraction, contact sheets, histogram/pixel-difference scene-change detection, brightness/contrast/saturation/edge/blur measurements, waveform, RMS/peak, silence and amplitude-jump detection, manual transcript and annotations, script statistics, style lock, template-based prompts, all exports.

## 7. Realistic local-AI candidates (Unverified candidates - none tested)
- Speech recognition: a small sherpa-onnx model (e.g. a tiny Whisper or small streaming Zipformer). Licences are generally Apache-2.0/MIT but must be checked per model. Needs bundling an ONNX runtime native library and the model (tens to low hundreds of MB).
- Image captioning/understanding: a very small vision-language model might fit on 4-6 GB RAM, but quality and speed on a Helio P70 are doubtful. Treat as a possible Phase 6 experiment, expected to fail the usefulness bar.
- Local LLM for prompts: Unlikely to be worth it on this CPU; the template engine is the plan.

## 8. Possibly too demanding
Any vision-language model, any on-device LLM, optical flow at full resolution, and decoding every frame of long videos. Also long speech-recognition runs (battery and heat). These stay optional or are replaced by sparse sampling.

## 9. Size estimates (Estimates, not measurements)
Phase 1 debug APK: roughly 8-15 MB (Compose + Room + AndroidX, unshrunk). A release build with shrinking would be smaller. Adding a speech model would add tens to a few hundred MB depending on the model. Real numbers will be reported from the CI-built APK.

## 10. Staged plan
1. Foundation: project, navigation, DB, picker, metadata (this delivery).
2. Video Lab: preview, range, frames, contact sheet, scene detection, measurements, shot timeline.
3. Audio Lab: decode, waveform, RMS/peak, silence, annotations, transcript editor.
4. Prompt Workshop: templates, style lock, 22-field prompts, variations, copy.
5. Persistence and exports: TXT/MD/CSV/JSON/PDF, backup and restore.
6. Evaluate local models one at a time, on the phone.
7. Device test pass (airplane mode, large/short/no-audio/unsupported files, low storage, restart, repeated use), with emulator and physical results kept separate.

## Build environment finding (Verified)
The workspace I build in has no Android SDK and blocks Google Maven, Maven Central, the Gradle plugin portal and dl.google.com (HTTP 403), so Android code cannot be compiled or an APK produced there. GitHub is reachable from it, and a GitHub Actions workflow is included to do the compile. **No APK has been built and none of this code has been compiled yet.**
